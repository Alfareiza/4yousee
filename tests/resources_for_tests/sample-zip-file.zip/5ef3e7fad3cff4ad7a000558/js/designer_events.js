DesignerEvents = (function (global) {
    var _eventsPerObject = {};

    function DesignerEvents(eventsPerObject) {
        if (eventsPerObject) {
            _eventsPerObject = eventsPerObject;
        }
        addDesignerEventListener();
    }

    var addDesignerEventListener = function() {
        global.addEventListener('designerEvent', function(e) {
            handleDesignEvent(e.detail.object, e.detail.event);
        });
    };

    var handleDesignEvent = function(object, event) {
        if (_eventsPerObject.hasOwnProperty(object) && _eventsPerObject[object].hasOwnProperty(event)) {
            _eventsPerObject[object][event]();
        }
    };

    return DesignerEvents;
})(window);